<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Crypto Tracker</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content :fullscreen="true">
      <ion-list>
        <ion-item v-for="coin in coins" :key="coin.id">
          <ion-label>
            <h2>{{ coin.name }} ({{ coin.symbol }})</h2>
            <p>Price: ${{ coin.price_usd }}</p>
          </ion-label>
        </ion-item>
      </ion-list>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const coins = ref([])

onMounted(async () => {
  try {
    const res = await fetch('https://api.coinlore.net/api/tickers/')
    const data = await res.json()
    coins.value = data.data
  } catch (error) {
    console.error('Error fetching data:', error)
  }
})
</script>
